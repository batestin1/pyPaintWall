<h1 align="center">
<img src="https://img.shields.io/static/v1?label=pyPaintWall%20POR&message=MAYCON%20BATESTIN&color=7159c1&style=flat-square&logo=ghost"/>


<h3> <p align="center">pyPaintWall</p> </h3>
<h3> <p align="center"> ================= </p> </h3>

>> <h3> Resume </h3>

<p> This library allows you to immediately calculate the area of a wall (width and height) and returns the liters of paint needed to paint it.
Very useful for home!</p>

>> <h3> How Works </h3>

<p> install </p>

```
pip install pyPaintWall

```
<p> on script </p>

```
from pyPaintWall import *

pyPaintWall(width, height)

```

